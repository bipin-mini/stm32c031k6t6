/*
 * FLASH.c
 *
 *  Created on: Mar 19, 2025
 *      Author: bortolut
 */
#include "FLASH.h"

#include "stm32c031xx.h"
#include "stm32c0xx.h"

FLASH_Status FLASH_ProgramDoubleWord(uint32_t dataWrite1, uint32_t dataWrite2, uint32_t address){
  FLASH_Unlock();
  FLASH_CheckExecution(); // Check if no FLASH operation is ongoing and clear programming errors

  // Checks if ERASE or PROGRAM operations are executing
  if(READ_BIT(FLASH->SR, FLASH_SR_CFGBSY) == 0x0U){
    /* Enable FLASH programming */
    SET_BIT(FLASH->CR, FLASH_CR_PG);

    /* Program 32 bit word*/
    *(uint32_t *)address = (uint32_t)dataWrite1;

    /* Barrier to ensure programming is performed in 2 steps, in right order
            (independently of compiler optimization behavior) */
    __ISB();

     /* Program second 32 bit word */
     *(uint32_t *)(address + 4U) = (uint32_t)(dataWrite2);

    /* Disable FLASH programming */
    CLEAR_BIT(FLASH->CR, FLASH_CR_PG);

    /* Clear EOP bit */
    SET_BIT(FLASH->SR, FLASH_SR_EOP);

    FLASH_CheckExecution(); // Check if no FLASH operation is ongoing and clear programming errors

    return FLASH_OK;
  }

  return FLASH_ERROR;
}


FLASH_Status FLASH_Erase(uint32_t page1, uint32_t page2){
  //uint32_t pages[2] = {6U, 7U};

  FLASH_Unlock(); // Allow FLASH operations
  FLASH_CheckExecution(); // Check if no FLASH operation is ongoing and clear programming errors

  // Check if FLASH is free (no programming or erase ongoing)
  if (READ_BIT(FLASH->SR, FLASH_SR_CFGBSY) == 0x0U){
    // ENABLE PAGE ERASE | selectedPage | StartErase
    WRITE_REG(FLASH->CR, FLASH_CR_PER | (page1 <<  FLASH_CR_PNB_Pos) | FLASH_CR_STRT);

    FLASH_CheckExecution(); // Check if no FLASH operation is ongoing and clear programming errors

    WRITE_REG(FLASH->CR, FLASH_CR_PER | (page2 <<  FLASH_CR_PNB_Pos) | FLASH_CR_STRT);

    FLASH_CheckExecution(); // Check if no FLASH operation is ongoing and clear programming errors

    return FLASH_OK;
  }
  else{
      return FLASH_ERROR;
  }
}

FLASH_Status FLASH_Page_Erase(uint8_t page){
  FLASH_Unlock();		  // Allow FLASH operations
  FLASH_CheckExecution(); // Check if no FLASH operation is ongoing and clear programming errors

  // Check if FLASH is free (no programming or erase ongoing)
  if (READ_BIT(FLASH->SR, FLASH_SR_CFGBSY) == 0x0U){
    // ENABLE PAGE ERASE | selectedPage | StartErase
    WRITE_REG(FLASH->CR, FLASH_CR_PER | (page <<  FLASH_CR_PNB_Pos) | FLASH_CR_STRT);

    FLASH_CheckExecution(); // Check if no FLASH operation is ongoing and clear programming errors

    return FLASH_OK;
  }
  else{
      return FLASH_ERROR;
  }
}

// AUXILIARY FUNCTION DEFINITIONS
// Allow FLASH operations
FLASH_Status FLASH_Unlock(void){
  if (READ_BIT(FLASH->CR, FLASH_CR_LOCK) != 0x00U){
    /* Authorize the FLASH Registers access */
    WRITE_REG(FLASH->KEYR, FLASH_KEY1);
    WRITE_REG(FLASH->KEYR, FLASH_KEY2);

      /* verify Flash is unlock */
      if (READ_BIT(FLASH->CR, FLASH_CR_LOCK) != 0x00U){
              return FLASH_ERROR;
      }
  }
  return FLASH_OK;
}

// Check if no FLASH operation is ongoing and clear programming errors
FLASH_Status FLASH_CheckExecution(void){
  uint32_t error = 0;

  /* Checks if FLASH is executing another operation */
  if (READ_BIT(FLASH->SR, FLASH_SR_BSY1) == 0x00U){
    /* Check if any errors happen due to last program*/
    error = FLASH->SR & FLASH_FLAG_SR_ERROR;
    WRITE_REG(FLASH->SR, error);

    /* Clear bits */
    CLEAR_BIT(FLASH->CR, FLASH_CR_PNB);
    CLEAR_BIT(FLASH->CR, FLASH_CR_PER);

    if (error != 0x00U){
            return FLASH_ERROR;
    }
  }

  return FLASH_OK;
}
