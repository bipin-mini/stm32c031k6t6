/*
 * FLASH.h
 *
 *  Created on: Mar 19, 2025
 *      Author: bortolut
 */

#ifndef INC_FLASH_H_
#define INC_FLASH_H_

#include <stdint.h>

#include "stm32c031xx.h"
#include "stm32c0xx.h"

typedef enum
{
  FLASH_OK       = 0x00,
  FLASH_ERROR    = 0x01,
  FLASH_TIMEOUT  = 0x02
} FLASH_Status;

// FLASH Unlock Keys
#define FLASH_KEY1 0x45670123
#define FLASH_KEY2 0xCDEF89AB

#define FLASH_PAGE_SIZE 0x00000800U  /*!< FLASH page size */
#define FLASH_FLAG_SR_ERROR (FLASH_SR_EOP  | FLASH_SR_OPERR | FLASH_SR_PROGERR |  \
							FLASH_SR_PGAERR | FLASH_SR_SIZERR  | FLASH_SR_PGSERR |   \
							FLASH_SR_MISERR | FLASH_SR_FASTERR | /*FLASH_SR_RDERR |*/   \
							FLASH_SR_OPTVERR)

FLASH_Status FLASH_ProgramDoubleWord(uint32_t dataWrite1, uint32_t dataWrite2, uint32_t address);
FLASH_Status FLASH_Erase(uint32_t page1, uint32_t page2);
FLASH_Status FLASH_Page_Erase(uint8_t page);

FLASH_Status FLASH_Unlock(void);
FLASH_Status FLASH_CheckExecution(void);

#endif /* INC_FLASH_H_ */
