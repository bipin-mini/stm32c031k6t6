#ifndef INC_EEPROM_EMULATION_H_
#define INC_EEPROM_EMULATION_H_

#include <stdint.h>

#define PAGE_START(pageNumber) ((pageNumber * FLASH_PAGE_SIZE) + FLASH_BASE)
#define PAGE_END(pageNumber) (((pageNumber * FLASH_PAGE_SIZE) + FLASH_BASE) + FLASH_PAGE_SIZE)

#define PAGE_START_INIT(pageNumber, i) ((pageNumber * FLASH_PAGE_SIZE) + FLASH_BASE + 8 * i) 

#define READ_FLASH(ADDR) (*(__IO uint32_t*) ADDR)
#define CLEAR_ADDR 0xFFFFFFFF
#define MAX_8BITSDIVISIONS 4U

#define VIRTUALADDRESS_MASK 0x0000FFFFU
#define DATASIZE_MASK 0x0F000000U
#define NUMBEROFDATA_MASK 0xF0000000U

#define D32      0U
#define D16D16   1U
#define D8D16D8  2U
#define D8D8D16  3U
#define D16D8D8  4U
#define D8D8D8D8 5U

typedef enum{
 EEPROM_OK          = 0x00U,
 EEPROM_ERROR       = 0x01U,
 EEPROM_OVERFLOW    = 0x02U,
 EEPROM_WAIT        = 0x03U,
 EEPROM_WRITE_ERROR = 0x04U,
} EEPROM_Status;

struct currentPage{
  uint32_t pageNumber;
  uint32_t pageStart;
  uint32_t pageEnd;
};

struct EEPROMData{
  uint32_t receivedData[MAX_8BITSDIVISIONS];
  uint8_t dataSize[MAX_8BITSDIVISIONS];
  uint8_t numberOfData;
  uint16_t virtualAddress;
};

EEPROM_Status EEPROM_Init(uint32_t* init_variables);
uint32_t EEPROM_CurrentAddress(void);
EEPROM_Status EEPROM_Write8Bits(uint8_t data, uint16_t virtualAddress);
EEPROM_Status EEPROM_WriteData(uint32_t *data, uint8_t dataSize, uint8_t numberOfData, uint16_t virtualAddress);
EEPROM_Status EEPROM_AssembleDoubleWord(struct EEPROMData blockData);
EEPROM_Status verifyFlashIntegrity(struct EEPROMData blockData, uint32_t address);
void EEPROM_SwapPages(void);

void EEPROM_DataTransfer(void);
uint8_t FLASH_ReadMemory8bits(uint16_t virtualAddress);

uint32_t FLASH_ReadMemory(uint16_t virtualAddress);
uint32_t locateData(uint32_t address, uint32_t virtualAddress);
uint32_t extract_bits(uint32_t data, uint8_t sizes[], uint8_t index);

#endif /* INC_EEPROM_EMULATION_H_ */