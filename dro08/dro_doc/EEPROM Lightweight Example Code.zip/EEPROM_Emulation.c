/*
* EEPROM_Emulation.c
*
*  Created on: Mar 19, 2025
*      Author: bortolut
*/

#include "EEPROM_Emulation.h"
#include "FLASH.h"
#include "main.h"

#include "stm32c031xx.h"
#include "stm32c0xx.h"

#include "string.h"

// Structure to hold current page information
static struct currentPage page;

// Variables to store current address
static uint32_t currentFlashAddress = 0U;

/**
* @brief Initializes the EEPROM by determining which page has data and setting the current address.
* @return EEPROM_Status - Status of the initialization (EEPROM_OK or EEPROM_ERROR).
*/
EEPROM_Status EEPROM_Init(uint32_t* init_variables){
  // Flash Erase Flag
  uint8_t flashErased = 0U;

  // Verification Variables
  uint8_t FirstPageverification = 0U;
  uint8_t SecondPageverification = 0U;

  // Searches if the init_variables are already written in the beginning of the pages
  for (uint8_t i = 0; i < INIT_VARIABLE_NUMBER; i++){

    if(READ_FLASH(PAGE_START_INIT(FIRST_PAGE, i)) == init_variables[i]){
      FirstPageverification += 1U;
    }
    else if((READ_FLASH(PAGE_START_INIT(SECOND_PAGE, i))) == init_variables[i]){
      SecondPageverification += 1U;
    }
  }

  if (FirstPageverification == INIT_VARIABLE_NUMBER){
      // If PAGE6 is current page
      page.pageNumber = FIRST_PAGE;
      page.pageStart = PAGE_START(FIRST_PAGE);
      page.pageEnd = PAGE_END(FIRST_PAGE);
  }
  else if (SecondPageverification == INIT_VARIABLE_NUMBER){
    // If PAGE7 is current page
      page.pageNumber = SECOND_PAGE;
      page.pageStart = PAGE_START(SECOND_PAGE);
      page.pageEnd = PAGE_END(SECOND_PAGE);
  }
  else{
    // In case the init_variables are not found, erase both flash pages and set FIRST_PAGE as current page
    flashErased = 1U;
    FLASH_Erase(FIRST_PAGE, SECOND_PAGE);
    page.pageNumber = FIRST_PAGE;
    page.pageStart = PAGE_START(FIRST_PAGE);
    page.pageEnd = PAGE_END(FIRST_PAGE);
  }

  // Get the current address in the FLASH
  uint32_t currentAddress = EEPROM_CurrentAddress();

   // Check if the current address is valid
  if(currentAddress != EEPROM_ERROR){
      if((currentAddress >= FLASH_BASE) && (currentAddress < (FLASH_BASE + FLASH_SIZE))){
          if(flashErased == 1U){
              // EEPROM Initialization Variables
              for (uint8_t iteration = 0U; iteration < INIT_VARIABLE_NUMBER; iteration++){
                  EEPROM_Write8Bits(init_variables[iteration], iteration);
              }
                return EEPROM_OK;
           }
          else{
              return EEPROM_OK;
          }
    }
    // Return Error if currentAddress is outside valid bounds
    return EEPROM_ERROR;
  }
  // Return Error if currentAddress function failed
  return EEPROM_ERROR;
}

/**
* @brief Gets the current address in the FLASH.
* @return uint32_t - The current address or an error code.
*/
uint32_t EEPROM_CurrentAddress(void){
  // Start searching from the beginning of the page
  uint32_t pageAddress = (page.pageStart);

  // Iterate through the page memory in steps of 8 bytes
  for (uint32_t i = 0U; (pageAddress + i) <= page.pageEnd; i += 8U){
     // Calculate the current address
     uint32_t currentAddress = (pageAddress + i);
    
      // Check if the block flag at the current address is not clear
     if ((READ_FLASH(currentAddress)) == CLEAR_ADDR){
       // Set the current flash address and return it
       currentFlashAddress = (pageAddress + i);
       return currentFlashAddress;
     }

  }
  // Return an error code if the address is not found
  return EEPROM_ERROR;
}

/**
* @brief Writes 8 bits of data to the FLASH.
* @param data - Data to be written (8 bits).
* @param virtualAddress - The virtual address to write the data to.
* @return EEPROM_Status - Status of the write operation (EEPROM_OK, EEPROM_ERROR).
*/
EEPROM_Status EEPROM_Write8Bits(uint8_t data, uint16_t virtualAddress){
   // Structure to hold data
  struct EEPROMData DataInfo;
  
  DataInfo.receivedData[0] = data;
  DataInfo.dataSize[0] = 32U;
  
  for (uint8_t iteration = 1U; iteration <= 3U; iteration++){
     DataInfo.receivedData[iteration] = 0U;
     DataInfo.dataSize[iteration] = 0U;
  }
  
  DataInfo.numberOfData = 1U;
  DataInfo.virtualAddress = virtualAddress;

  // Assemble the double word and write it to the FLASH
  if(EEPROM_AssembleDoubleWord(DataInfo) != EEPROM_OK){
     return EEPROM_ERROR;
  }
  return EEPROM_OK;
}

/**
* @brief Writes data to the FLASH.
* @param data - Pointer to the array of data to be written.
* @param dataSize - Data Size MACRO (D32, D16D16, D8D16D8, D8D8D16, D16D8D8 or D8D8D8D8).
* @param numberOfData - Number of data segments to be written.
* @param virtualAddress - The virtual address to write the data to.
* @return EEPROM_Status - Status of the write operation (EEPROM_OK, EEPROM_ERROR, or EEPROM_OVERFLOW).
*/
EEPROM_Status EEPROM_WriteData(uint32_t *data, uint8_t dataSize, uint8_t numberOfData, uint16_t virtualAddress){
  // Structure to hold data
  struct EEPROMData DataInfo;

  // Array to keep macro convertion to data size divisions
  uint8_t convertedDataSize[MAX_8BITSDIVISIONS] = {0U, 0U, 0U, 0U};

  // Check if the number of data segments exceeds the maximum allowed or if the current flash address is not clear
  if((numberOfData > MAX_8BITSDIVISIONS) || (READ_FLASH(currentFlashAddress) != CLEAR_ADDR)){
           return EEPROM_OVERFLOW;
  }

  // Verify if datasize MACRO is within expected values
  if(dataSize > 5U){
    return EEPROM_ERROR;
  }

  // Convert data size MACRO in data size divisions
  switch (dataSize) {
    case D32:
            convertedDataSize[0] = 32U;
            break;
    case D16D16:
            convertedDataSize[0] = 16U;
            convertedDataSize[1] = 16U;
            break;
    case D8D16D8:
            convertedDataSize[0] = 8U;
            convertedDataSize[1] = 16U;
            convertedDataSize[2] = 8U;
            break;
    case D8D8D16:
            convertedDataSize[0] = 8U;
            convertedDataSize[1] = 8U;
            convertedDataSize[2] = 16U;
            break;
    case D16D8D8:
            convertedDataSize[0] = 16U;
            convertedDataSize[1] = 8U;
            convertedDataSize[2] = 8U;
            break;
    case D8D8D8D8:
            convertedDataSize[0] = 8U;
            convertedDataSize[1] = 8U;
            convertedDataSize[2] = 8U;
            convertedDataSize[3] = 8U;
            break;
    default:
            return EEPROM_ERROR;
  }

  // Copy the data and data sizes to the DataInfo structure
  for(uint8_t i = 0U; i < numberOfData; i++){
      DataInfo.receivedData[i] = data[i];
      DataInfo.dataSize[i] = convertedDataSize[i];
  }

  // Set the number of data segments and the virtual address in the DataInfo structure
  DataInfo.numberOfData = numberOfData;
  DataInfo.virtualAddress = virtualAddress;

  // Assemble the double word and write it to the FLASH
  if(EEPROM_AssembleDoubleWord(DataInfo) != EEPROM_OK){
     return EEPROM_ERROR;
  }

  return EEPROM_OK;
}

/**
* @brief Assembles a double word (64 bits) to be written to the FLASH.
* @param blockData - Structure containing the EEPROM data to be assembled.
* @return EEPROM_Status - Status of the operation (EEPROM_OK, EEPROM_ERROR, or EEPROM_OVERFLOW).
*/
EEPROM_Status EEPROM_AssembleDoubleWord(struct EEPROMData blockData){
   // Variable to store the assembled data block
  uint32_t dataBlock = 0U;

  // Variable to keep track of the bit shift for assembling the data block
  uint8_t dataBlockShift = 0U;

  // Variable to store the information block
  uint32_t informationBlock = 0U;

  // Variable to keep track of the bit shift for assembling the information block
  uint8_t bitShift = 0U;

  // Assemble the block of 32 bit Data
  for (uint8_t iteration = 0U; iteration < blockData.numberOfData; ++iteration) {
    // Combine the received data into the data block by shifting and OR-ing
    dataBlock |= (blockData.receivedData[iteration]) << dataBlockShift;

    // Update the bit shift based on the size of the current data segment
    dataBlockShift += blockData.dataSize[iteration];
  }

   // Check for overflow if the total data size exceeds 32 bits
  if(dataBlockShift > 32U){
      return EEPROM_OVERFLOW;
  }

  // Assemble the information block
  // 16 bits Virtual Address
  informationBlock |= blockData.virtualAddress << bitShift;
  bitShift += 16U;

  // 8 bits PLACEHOLDER space
  informationBlock |= 0U << bitShift;
  bitShift += 8U;

  // Variable to alternate between 1 and 0 for organization bits
  uint8_t organizationBinary = 1U;

  // First 4 bits ORGANIZATION
  for (uint8_t iteration = 0U; iteration < blockData.numberOfData; ++iteration) {

    // Set the organization bits based on the data size
     switch (blockData.dataSize[iteration]) {
       case 8U:
         informationBlock |= organizationBinary << bitShift;
         bitShift++;
       break;

       case 16U:
         informationBlock |= organizationBinary << bitShift;
         bitShift++;
         informationBlock |= organizationBinary << bitShift;
         bitShift++;
       break;

       case 32U:
         informationBlock |= organizationBinary << bitShift;
         bitShift++;
         informationBlock |= organizationBinary << bitShift;
         bitShift++;
         informationBlock |= organizationBinary << bitShift;
         bitShift++;
         informationBlock |= organizationBinary << bitShift;
         bitShift++;
       break;

       default:
         return EEPROM_ERROR;
     }

     // Alternate the organization binary between 1 and 0
     if(organizationBinary == 0U){
       organizationBinary = 1U;
     }
     else{
       organizationBinary = 0U;
     }
  }
  // Last 4 bits ORGANIZATION
  informationBlock |= (blockData.numberOfData << bitShift);
  bitShift += 4U;

  // Check if the current flash address exceeds the page end
  if ((currentFlashAddress) >= page.pageEnd){
    EEPROM_DataTransfer();
  }

  // Write the assembled data block and information block to the current flash address
  if (FLASH_ProgramDoubleWord(dataBlock, informationBlock, currentFlashAddress) == FLASH_OK){
    // Verify the integrity of the written data
    if(verifyFlashIntegrity(blockData, currentFlashAddress) == EEPROM_WRITE_ERROR){
      return EEPROM_WRITE_ERROR;
    }
    
    // Update the flash address and reset the virtual address
    currentFlashAddress += 8U;
    blockData.virtualAddress = 0U;

    // Clear all data-related variables
    memset(blockData.receivedData, 0U, sizeof(blockData.receivedData));
    memset(blockData.dataSize, 0U, sizeof(blockData.dataSize));
    blockData.numberOfData = 0U;

    return EEPROM_OK;
  }
  else{
    return EEPROM_ERROR;
  }
}

/**
* @brief Verifies the integrity of data stored in flash memory.
* @param blockData - Structure containing the EEPROM data to be verified.
* @param address - The flash memory address where the data is stored.
* @return EEPROM_Status - Status of the verification (EEPROM_OK or EEPROM_WRITE_ERROR).
*/
EEPROM_Status verifyFlashIntegrity(struct EEPROMData blockData, uint32_t address){
  // Variable to keep track of the bit shift for rebuilding the data block
 uint8_t dataBlockShift = 0U;

  // Iterate through the data in the blockData structure
 uint32_t rebuiltData = 0U;

 for (uint8_t iteration = 0U; iteration < blockData.numberOfData; ++iteration) {
   // Rebuild the data block by shifting and combining the received data
  rebuiltData |= (blockData.receivedData[iteration]) << dataBlockShift;

  // Update the bit shift based on the size of the current data segment
  dataBlockShift += blockData.dataSize[iteration];
}

  // Read the data stored at the specified flash memory address
  uint32_t readAddress = READ_FLASH(address);

  // Compare the rebuilt data with the data read from flash memory
  if (readAddress == rebuiltData){
    return EEPROM_OK;
  }

  return EEPROM_WRITE_ERROR;
}

/**
* @brief Reads the memory address of a virtual address in the EEPROM.
* @param virtualAddress - The virtual address to read.
* @return uint32_t - The memory address of the virtual address or an error code.
*/
uint32_t FLASH_ReadMemory(uint16_t virtualAddress)
{
  // Start searching from the end of the page, moving backwards
  uint32_t addressSearch = (page.pageEnd - 8U);

  // Variables to store the start and end of the virtual address range
  uint32_t virtualAddressStart = 0U;
  uint32_t virtualAddressEnd = 0U;

  // Iterate through the page memory from end to start, in steps of 8 bytes
 for (uint32_t i = 0; (addressSearch + i) >= page.pageStart; i -= 8U){

   // Read the control bits at the current address
   volatile uint32_t controlBitAddress = READ_FLASH(((addressSearch + i) + 4U));

    // Extract the start of the virtual address range
   virtualAddressStart = (controlBitAddress & VIRTUALADDRESS_MASK);

    // Calculate the end of the virtual address range
   virtualAddressEnd = ((controlBitAddress & NUMBEROFDATA_MASK) >> 28U) + virtualAddressStart - 1U;

   // Check if the virtual address start is invalid (0xFF)
   if(virtualAddressStart == 0xFF){
       return EEPROM_ERROR;
   }

   // Check if the given virtual address falls within the current range
   if((virtualAddress >= virtualAddressStart) & (virtualAddress <= virtualAddressEnd)){

     // Locate and return the data for the given virtual address
       return locateData((addressSearch + i), virtualAddress);
   }
 }
  return EEPROM_ERROR;
}

/**
* @brief Reads the memory address in 8 bit format of a virtual address in the EEPROM.
* @param virtualAddress - The virtual address to read.
* @return uint8_t - The memory address of the virtual address or an error code.
*/
uint8_t FLASH_ReadMemory8bits(uint16_t virtualAddress)
{
  // Start searching from the end of the page, moving backwards
  uint32_t addressSearch = (page.pageEnd - 8U);

  // Variables to store the start and end of the virtual address range
  uint32_t virtualAddressStart = 0U;
  uint32_t virtualAddressEnd = 0U;

  // Iterate through the page memory from end to start, in steps of 8 bytes
 for (uint32_t i = 0; (addressSearch + i) >= page.pageStart; i -= 8U){

   // Read the control bits at the current address
   volatile uint32_t controlBitAddress = READ_FLASH(((addressSearch + i) + 4U));

    // Extract the start of the virtual address range
   virtualAddressStart = (controlBitAddress & VIRTUALADDRESS_MASK);

    // Calculate the end of the virtual address range
   virtualAddressEnd = ((controlBitAddress & NUMBEROFDATA_MASK) >> 28U) + virtualAddressStart - 1U;

   // Check if the virtual address start is invalid (0xFF)
   if(virtualAddressStart == 0xFF){
       return EEPROM_ERROR;
   }

   // Check if the given virtual address falls within the current range
   if((virtualAddress >= virtualAddressStart) & (virtualAddress <= virtualAddressEnd)){

     // Locate and return the data for the given virtual address
       return (uint8_t)(locateData((addressSearch + i), virtualAddress));
   }
 }
  return EEPROM_ERROR;
}

/**
* @brief Locates the data for a given virtual address.
* @param address - The address to start the search.
* @param virtualAddress - The virtual address to locate.
* @return uint32_t - The data for the virtual address or an error code.
*/
uint32_t locateData(uint32_t address, uint32_t virtualAddress)
{
  // Read the data and control bits at the specified address
  volatile uint32_t dataAddress = READ_FLASH(address);
  volatile uint32_t controlBitAddress = READ_FLASH((address + 4U));

  // Extract the EEPROM data size, current virtual address, and number of data segments
  uint32_t EEPROM_datasize = ((controlBitAddress & DATASIZE_MASK) >> 24U);
  uint32_t currentVirtualAddress = (controlBitAddress & VIRTUALADDRESS_MASK);
  uint32_t numberOfData = ((controlBitAddress & NUMBEROFDATA_MASK) >> 28U);

   // Array to store the size of each data segment
  uint8_t allocation[4] = {0U, 0U, 0U, 0U};

   // Determine the allocation sizes based on the EEPROM data size
  switch (EEPROM_datasize) {
    case 15: // (1111)
            allocation[0] = 32;
            break;
    case 3: // (0011)
            allocation[0] = 16;
            allocation[1] = 16;
            break;
    case 9: // 1001
            allocation[0] = 8;
            allocation[1] = 16;
            allocation[2] = 8;
            break;
    case 13: // 1011
            allocation[0] = 8;
            allocation[1] = 8;
            allocation[2] = 16;
            break;
    case 11: // 1101
            allocation[0] = 16;
            allocation[1] = 8;
            allocation[2] = 8;
            break;
    case 5:  // 0101
            allocation[0] = 8;
            allocation[1] = 8;
            allocation[2] = 8;
            allocation[3] = 8;
            break;
    default:
            return EEPROM_ERROR;
            break;
  }

  // Iterate through the data segments to locate the data for the given virtual address
  uint8_t timesIterated = 0U;
  for (uint16_t iteration = currentVirtualAddress; iteration < (currentVirtualAddress + numberOfData); ++iteration) {

    // Check if the current iteration matches the virtual address
    if(iteration == virtualAddress){

      // Extract and return the bits corresponding to the virtual address
      return extract_bits(dataAddress, allocation, timesIterated);
    }
    timesIterated++;
  }
  return EEPROM_ERROR;
}

/**
* @brief Extracts bits from the data based on the sizes array.
* @param data - The data to extract bits from.
* @param sizes - The sizes array indicating the size of each segment.
* @param index - The index of the segment to extract.
* @return uint32_t - The extracted bits.
*/
uint32_t extract_bits(uint32_t data, uint8_t sizes[], uint8_t index) {
  // Calculate the starting bit position for the given index
  uint8_t start_bit = 0;
  for (int i = 0; i < index; i++) {
    start_bit += sizes[i];
  }

  // Calculate the mask to extract the required bits
  uint32_t mask = (1 << sizes[index]) - 1;

  // Shift the data to the right to align the required bits with the least significant bit
  uint32_t shifted_data = data >> start_bit;

  // Apply the mask to extract the required bits
  uint32_t extracted_bits = shifted_data & mask;

  return extracted_bits;
}

/**
* @brief Swaps the pages in the EEPROM.
*/
void EEPROM_SwapPages(void){
if (page.pageNumber == FIRST_PAGE){
  page.pageNumber = SECOND_PAGE;
  page.pageStart = PAGE_START(SECOND_PAGE);
  page.pageEnd = PAGE_END(SECOND_PAGE);
}
else{
  page.pageNumber = FIRST_PAGE;
  page.pageStart = PAGE_START(FIRST_PAGE);
  page.pageEnd = PAGE_END(FIRST_PAGE);
 }
}

/**
 * @brief Transfers data from the current EEPROM page to a new page.
 *
 * This function performs the following steps:
 * 1. Reads initialization variables from the beginning of the current EEPROM page.
 * 2. Swaps to a new EEPROM page.
 * 3. Writes the initialization variables to the start of the new EEPROM page.
 * 4. Copies the most recent data for each virtual address to the new EEPROM page.
 * 5. Erases the old EEPROM page.
 * 6. Re-initializes the EEPROM with the initialization variables.
 */
void EEPROM_DataTransfer(void) {
    // Array to store initialization variables
    uint32_t initData[INIT_VARIABLE_NUMBER];
    // Array to store most recent virtual adress values
    uint32_t recentData[INIT_VARIABLE_NUMBER];
    
    // Get initialization variables from the beginning of the current page
    for (uint8_t iteration = 0U; iteration < INIT_VARIABLE_NUMBER; iteration++) {
        initData[iteration] = READ_FLASH(PAGE_START_INIT(page.pageNumber, iteration));
    }
    
    for (uint8_t iteration = 0U; iteration < INIT_VARIABLE_NUMBER; iteration++) {
        recentData[iteration] = FLASH_ReadMemory(iteration);
    }
    
    // Swap to a new EEPROM page
    EEPROM_SwapPages();
    
    currentFlashAddress = page.pageStart;
    
    // Copy initialization variables to the start of the new page
    for (uint8_t iteration = 0U; iteration < INIT_VARIABLE_NUMBER; iteration++) {
        EEPROM_Write8Bits(initData[iteration], iteration);
    }
    
    // Get the most recent data for each virtual address and write it to the new page
    for (uint8_t iteration = 0U; iteration < INIT_VARIABLE_NUMBER; iteration++) {
        EEPROM_Write8Bits(recentData[iteration], iteration);
    }
    
    // Erase the old EEPROM page
    EEPROM_SwapPages();
    FLASH_Page_Erase(page.pageNumber);
    EEPROM_SwapPages();
    
    // Re-initialize the EEPROM with the initialization variables
    EEPROM_Init(initData);
}
